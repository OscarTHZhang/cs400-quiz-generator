Course: CS 400<br/>
Semester: Spring 2019<br/>
# Project Name: Quiz Generator
#### Team Members:
1. Haochen Shi, lec 001, hshi74@wisc.edu
2. Rui (Peter) Pan, lec 002, rpan33@wisc.edu
3. Bradley Mao, lec 002, jmao43@wisc.edu
4. Oscar Zhang, lec 002, tzhang383@wisc.edu

#### Notes or comments to grader
Open Main.java to run the application
